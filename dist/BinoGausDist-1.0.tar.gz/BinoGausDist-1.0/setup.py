from setuptools import setup

setup(name='BinoGausDist',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['BinoGausDist'],
      author = 'Ajitesh Gupta',
      author_email = 'ajiteshgupta13@gmail.com',
      zip_safe=False)
